CTEST_PARALLEL_LEVEL
--------------------

.. include:: ENV_VAR.txt

Specify the number of tests for CTest to run in parallel. See :manual:`ctest(1)`
for more information on parallel test execution.
