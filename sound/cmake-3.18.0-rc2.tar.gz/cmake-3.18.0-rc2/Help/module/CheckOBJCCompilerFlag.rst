.. cmake-module:: ../../Modules/CheckOBJCCompilerFlag.cmake
